import {Book} from "../app/book";

export const myBook: Book[] = [
    {name: 'mathBook', publisher:'mathSchool', author:'mathTeacher'},
    {name:"englishBook", publisher:"englishSchool", author:"englishTeacher"},
    {name: "historyBook", publisher:"historySchool", author:"historyTeacher"}
]