import { Injectable } from '@angular/core';
import {Book} from './book';
import {myBook} from '../assets/bookData';



@Injectable({
  providedIn: 'root'
})
export class LoadBookService {

  constructor() { }

  loadData(): Book[]{
    return myBook;
  }
}
