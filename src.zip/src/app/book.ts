export interface Book {
    name:string;
    publisher:string;
    author:string;
}