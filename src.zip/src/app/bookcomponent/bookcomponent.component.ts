import { Component, OnInit } from '@angular/core';
import {Book} from '../book';
import {LoadBookService} from '../load-book.service';

@Component({
  selector: 'app-bookcomponent',
  templateUrl: './bookcomponent.component.html',
  styleUrls: ['./bookcomponent.component.css']
})
export class BookcomponentComponent implements OnInit {

  myBookes: Book[];

  constructor(private myBook:LoadBookService) { }

  ngOnInit() {
    this.getData();
  }

  getData(){
    this.myBookes = this.myBook.loadData();
  }

}
